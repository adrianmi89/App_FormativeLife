
import { Offer, User } from "../data/index.js"
import { validate, errors } from "com"

const { SystemError, MatchError } = errors;

function retrieveOffersFromStudent(targetUserId) {
    validate.id(targetUserId, "targetUserId")

    return User.findById(targetUserId)
        .catch(error => { throw new SystemError(error.message) })
        .then(targetUser => {
            if (!targetUser)
                throw new MatchError("target user not found")

            return Offer.find({ candidates: targetUserId }).select("-__v").populate("candidates", "-__v -password -role").lean()
                .then(offers => {
                    //Saneamiento de datos
                    offers.forEach(offer => {
                        if (offer.candidates._id) {
                            const id = offer.candidates._id.toString();
                            delete offer.candidates._id;

                            offer.candidates.id = id;
                        }
                        offer.id = offer._id.toString()

                        delete offer._id;
                    })
                    return offers;
                })
        })
}

export default retrieveOffersFromStudent;